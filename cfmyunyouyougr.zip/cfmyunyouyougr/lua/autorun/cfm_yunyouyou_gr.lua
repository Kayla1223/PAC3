player_manager.AddValidModel( "CFM_YunYouyou_GR", "models/daniao/CFM_YunYouyou_GR/CFM_YunYouyou_GR_player.mdl" );
player_manager.AddValidHands( "CFM_YunYouyou_GR", "models/daniao/CFM_YunYouyou_GR/CFM_YunYouyou_GR_arms.mdl", 0, "00000000" )

local Category = "CrossFire Mobile"

local NPC = { 	Name = "CFM_YunYouyou_GR - Friendly", 
				Class = "npc_citizen",
				Model = "models/daniao/CFM_YunYouyou_GR/CFM_YunYouyou_GR_player.mdl",
				Health = "100",
				KeyValues = { citizentype = 4 },
				Weapons = { "weapons_smg1" },
				Category = Category	}

list.Set( "NPC", "CFM_YunYouyou_GR_f", NPC )

local Category = "CrossFire Mobile"

local NPC = { 	Name = "CFM_YunYouyou_GR - Hostile", 
				Class = "npc_combine_s",
				Model = "models/daniao/CFM_YunYouyou_GR/CFM_YunYouyou_GR_player.mdl",
				Squadname = "CFM_YunYouyou_GR",
				Numgrenades = "3",
				Health = "100",
				Category = Category	}

list.Set( "NPC", "CFM_YunYouyou_GR_h", NPC )