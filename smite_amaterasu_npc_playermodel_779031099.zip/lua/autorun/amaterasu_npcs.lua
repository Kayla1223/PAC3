local Category = "Friendly Smite Gods"

local NPC = { 	Name = "Amaterasu", 
				Class = "npc_citizen",
				Model = "models/Aileri/amaterasu/amaterasu_rebel.mdl",
				Health = "100",
				KeyValues = { citizentype = 4 },
                                Category = Category    }

list.Set( "NPC", "npc_amaterasu", NPC )

local Category = "Hostile Smite Gods"

local NPC = { 	Name = "Amaterasu", 
				Class = "npc_combine_s",
				Model = "models/Aileri/amaterasu/amaterasu_combine.mdl",
				Health = "100",
				Squadname = "PLAGUE",
				Numgrenades = "4",
                                Category = Category    }

list.Set( "NPC", "npc_amaterasu_enemy", NPC )





