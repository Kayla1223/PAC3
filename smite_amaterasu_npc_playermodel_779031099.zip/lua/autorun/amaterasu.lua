player_manager.AddValidModel( "Smite Amaterasu", "models/player/aileri_amaterasu.mdl" )
player_manager.AddValidHands( "Smite Amaterasu", "models/weapons/aileri_amaterasu_arms.mdl", 0, "00000000"  )

hook.Add("PlayerSpawn","AmaHandSkin",function( ply )
	timer.Simple(0, function()
		if !IsValid(ply) then return end

		if ply:GetModel()!="models/player/aileri_amaterasu.mdl" then return end

		local hands = ply:GetHands()
		if !IsValid(hands) then return end

		hands:SetSkin(ply:GetSkin())
	end)
end)




