player_manager.AddValidModel( "Reggaehair girl", "models/player/hhp227/reggaehair_girl.mdl" )

list.Set( "PlayerOptionsModel", "Reggaehair girl", "models/player/hhp227/reggaehair_girl.mdl" )